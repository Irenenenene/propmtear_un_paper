const express = require('express');
const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');
const app = express();
const port = 3001;

const openAiApiKey = 'sk-niLc0suiz-ZI7qmvQb1hTEA8brogcHnp7QlKM07ofwT3BlbkFJbj7cG06Iqj-agF690m4wc7dsr84QnekDDCKyTJQDsA'; // Replace with your actual API key

// Use 'public' folder to serve static files like index.html
app.use(express.static(path.join(__dirname, 'public')));

// Base paper files grouped by sections with multiple parts
const basePaperFiles = {
    "Introduccion-Parte-1": path.join(__dirname, 'text/introduction1.txt'),
    "Introduccion-Parte-2": path.join(__dirname, 'text/introduction2.txt'),
    "Introduccion-Parte-3": path.join(__dirname, 'text/introduction3.txt'),
    "Metodologia-Parte-1": path.join(__dirname, 'text/methodology1.txt'),
    "Metodologia-Parte-2": path.join(__dirname, 'text/methodology2.txt'),
    "Metodologia-Parte-3": path.join(__dirname, 'text/methodology3.txt'),
    "Resultados-Parte-1": path.join(__dirname, 'text/results1.txt'),
    "Resultados-Parte-2": path.join(__dirname, 'text/results2.txt'),
    "Resultados-Parte-3": path.join(__dirname, 'text/results3.txt'),
    "Conclusiones-Parte-1": path.join(__dirname, 'text/conclusions1.txt'),
    "Conclusiones-Parte-2": path.join(__dirname, 'text/conclusions2.txt'),
    "Conclusiones-Parte-3": path.join(__dirname, 'text/conclusions3.txt')
};

// Function to generate variations using OpenAI API
async function generateTextVariation(text) {
    try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${openAiApiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: "gpt-4o-mini",
                messages: [
                    { role: "system", content: "Eres un asistente que reformula texto académico." },
                    { role: "user", content: `Reformula el siguiente texto académico: ${text}` }
                ],
                max_tokens: 1200,
                temperature: 1
            })
        });

        const data = await response.json();
        if (!response.ok) {
            console.error("Error en la respuesta de OpenAI:", data);
            return null;
        }

        return data.choices[0].message.content.trim();
    } catch (error) {
        console.error("Error al generar la variación de la sección:", error);
        return null;
    }
}

// Function to generate chatbot response using OpenAI API
async function generateChatbotResponse(prompt) {
    try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${openAiApiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: "gpt-4o",
                messages: [
                    { 
                        role: "system", 
                        content: "Eres un asistente académico que ayuda a los usuarios a desbloquear secciones de un paper dando pistas sutiles sobre qué palabras clave utilizar. A continuación te indico qué tipo de respuestas pueden desbloquear cada sección: \n\n" +
                        "- **Introducción Parte 1**: Frases de duda o confusión desbloquean la introducción. Respuestas como 'quién sabe', 'no estoy seguro', 'quizá más tarde', 'me da pereza pensar en eso ahora', o emojis como 🤷‍♂️, 🙄 pueden funcionar.\n" +
                        "- **Introducción Parte 2**: Respuestas que impliquen olvido o dificultad para recordar desbloquean la parte 2 de la introducción. Usa frases como 'no me acuerdo', 'dejame recordar', 'esto es complicado', 'mi mente está en blanco', o emojis como 🌀.\n" +
                        "- **Introducción Parte 3**: Frases que denoten confusión, indecisión o que sean evasivas desbloquean la parte 3. Ejemplos: 'déjame adivinar', 'mejor no digo nada', 'estoy confundido', 'esa es buena pregunta', o emojis como 🤔, 🤷‍♀️.\n" +
                        "- **Metodología Parte 1**: Respuestas donde el usuario cambia letras de frases para mantener una vocal desbloquean la metodología. Ejemplos: 'michis gricis mi gistirii sigir liyindi', 'muchus grucus mu gusturuu sugur luyundu'.\n" +
                        "- **Metodología Parte 2**: Similar a la parte 1, pero usa la frase 'dame más texto' modificada. Ejemplos: 'dimi mus tixto', 'doma mis texlo', 'dumi mus toxte'.\n" +
                        "- **Metodología Parte 3**: Respuestas con variaciones de 'genera el texto'. Ejemplos: 'ginira il tixto', 'genuri ul texlu', 'ganira il tuxte'.\n" +
                        "- **Resultados Partes 1, 2, 3**: Respuestas con emojis específicos desbloquean estas secciones. Usa emojis como 🌵, 🌼, 🦋, 🦚, 🧿, 🍄, 🌿, 🎭, 🔔, 📸, entre otros.\n" +
                        "- **Conclusiones Parte 1, 2, 3**: Respuestas afectivas desbloquean las conclusiones. Ejemplos: 'qué interesante, muchos besos a tus padres', 'qué bien redactado, la tía te manda recuerdos', 'guape, tus amigues te mandan recuerdos'.\n\n" +
                        "Tu objetivo es ayudar al usuario a desbloquear estas secciones sugiriendo indirectamente qué tipo de respuesta podría ser útil para avanzar. Sé un poco misterioso pero útil, sugiriendo de manera sutil cuando el usuario esté cerca de una respuesta adecuada."
                    },
                    { role: "user", content: prompt }
                ],
max_tokens: 300,
temperature: 0.7


            })
        });

        const data = await response.json();
        if (!response.ok) {
            console.error("Error en la respuesta de OpenAI para el chatbot:", data);
            return "[Respuesta no disponible]";
        }

        return data.choices[0].message.content.trim();
    } catch (error) {
        console.error("Error al generar la respuesta del chatbot:", error);
        return "[Respuesta no disponible]";
    }
}

// Route to generate paper variation
app.get('/generate-paper', async (req, res) => {
    const sectionsToGenerate = req.query.sections ? req.query.sections.split(',') : [];
    let generatedPaper = {};
    let chatbotResponse = "";

    // Generate chatbot response regardless of section completion
    try {
        if (req.query.prompt && req.query.prompt.trim() !== "") {
            console.log("Generating chatbot response for prompt:", req.query.prompt);
            chatbotResponse = await generateChatbotResponse(req.query.prompt);
        } else {
            console.warn("No prompt provided for chatbot response");
            chatbotResponse = "[Respuesta no disponible]";
        }
    } catch (error) {
        console.error("Error al generar la respuesta del chatbot:", error);
        chatbotResponse = "[Respuesta no disponible]";
    }

    // Generate paper content if a section is requested
    for (let section of sectionsToGenerate) {
        if (basePaperFiles[section]) {
            try {
                // Read content from the corresponding file for the section part
                const content = fs.readFileSync(basePaperFiles[section], 'utf8');
                
                // Generate variation using OpenAI API
                const variedContent = await generateTextVariation(content);
                
                // Store the varied content only if it is not null
                if (variedContent) {
                    generatedPaper[section] = variedContent;
                }
            } catch (error) {
                console.error(`Error al leer el archivo para la sección '${section}':`, error);
            }
        } else {
            console.warn(`No se encontraron archivos para la sección: ${section}`);
        }
    }

    console.log("Chatbot response generated:", chatbotResponse);

    res.json({ paper: generatedPaper, chatbotResponse });
});

// Start the server
app.listen(port, () => {
    console.log(`Servidor corriendo en el puerto ${port}`);
});
