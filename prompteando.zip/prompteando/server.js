const express = require('express');
const path = require('path');
const fetch = require('node-fetch'); // Asegúrate de tener `node-fetch` instalado

const app = express();
const port = 3001;
const openAiApiKey = 'TU_API_KEY_AQUÍ'; // Asegúrate de reemplazar con tu clave API real

// Servir archivos estáticos desde la carpeta 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Texto base del paper dividido en secciones
const basePaper = {
    "Introducción": "Prompt, es en inglés inmediato y solicitud al mismo tiempo. Esta etimología polisémica que  ahora es también — para el resto de realidades no anglófonas — ese fragmento textual a través del que interactuamos con sistemas de inteligencia artificial; deviene el reflejo semántico de los procesos de aceleración sociotécnica que acostumbra a utilizar el sistema tecnocapitalista para cumplir con su paradigma de crecimiento exponencial . Estas tendencias aceleracionistas que procuran conceder lo deseado en el menor tiempo posible, en nombre de la máxima eficiencia, nos han conducido a lo que algunos autores han denominado sociedades del sofoco y la fatiga (Espluga, 2021) repercutiendo asimismo en la producción textual e iconográfica de los últimos dos años través de la implementación de la ingeniería de la demanda o prompt engineering. ",
    "Metodología": "Curabitur pretium tincidunt lacus. Nulla gravida orci a odio...",
    "Resultados": "Sed ut perspiciatis unde omnis iste natus error...",
    "Conclusiones": "At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis..."
};

// Función para generar variaciones de las secciones del paper usando la API de OpenAI
async function generateSectionVariation(section) {
    try {
        console.log("Conectando a la API de OpenAI...");

        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer sk-niLc0suiz-ZI7qmvQb1hTEA8brogcHnp7QlKM07ofwT3BlbkFJbj7cG06Iqj-agF690m4wc7dsr84QnekDDCKyTJQDsA`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: "gpt-4o-mini",  // Asegúrate de que el modelo es compatible
                messages: [
                    { role: "system", content: "Eres un asistente que reformula texto académico." },
                    { role: "user", content: `Reformula el siguiente texto académico de manera que mantenga el contenido pero con ligeras variaciones de estilo: ${section}` }
                ],
                max_tokens: 200,
                temperature: 0.7
            })
        });

        const data = await response.json();
        if (!response.ok) {
            console.error("Error en la respuesta de OpenAI:", data);
            throw new Error(data.error.message);
        }

        console.log("Respuesta de OpenAI:", data.choices[0].message.content.trim());
        return data.choices[0].message.content.trim();
    } catch (error) {
        console.error("Error al generar la variación de la sección:", error);
        return section; // Devuelve la sección original si hay un error
    }
}

// Ruta para generar un paper variado
app.get('/generate-paper', async (req, res) => {
    const sectionsToGenerate = req.query.sections.split(',');
    let generatedPaper = {};

    for (let section of sectionsToGenerate) {
        if (basePaper[section]) {
            try {
                generatedPaper[section] = await generateSectionVariation(basePaper[section]);
            } catch (error) {
                console.error(`Error al generar variación para ${section}:`, error);
                generatedPaper[section] = basePaper[section]; // Devolver el original si hay error
            }
        }
    }

    res.json({ paper: generatedPaper });
});

// Función de prueba para verificar la conectividad con OpenAI
async function testOpenAIConnection() {
    try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer sk-niLc0suiz-ZI7qmvQb1hTEA8brogcHnp7QlKM07ofwT3BlbkFJbj7cG06Iqj-agF690m4wc7dsr84QnekDDCKyTJQDsA`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: "gpt-4o-mini",
                messages: [{ role: "user", content: "Hola, ¿puedes confirmar esta conexión?" }],
                max_tokens: 10
            })
        });
        const data = await response.json();
        console.log("Prueba de conexión con OpenAI:", data);
    } catch (error) {
        console.error("Error al intentar conectar con OpenAI:", error);
    }
}

// Ejecuta la prueba de conexión
testOpenAIConnection();

app.listen(port, () => {
    console.log(`Servidor corriendo en el puerto ${port}`);
});
